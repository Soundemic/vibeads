# Vibeads — AI Video Studio

**Turn any link into a viral video in 60 seconds.**

Paste a product page, article, Amazon listing, or social post. Vibeads generates a platform-optimised script via Claude, renders the video, and dispatches it across TikTok, Instagram, YouTube, and LinkedIn — automatically through n8n.

---

## Stack

| Layer       | Technology                                      |
|-------------|--------------------------------------------------|
| Framework   | Next.js 14 (App Router, Edge Runtime)            |
| Styling     | Tailwind CSS + custom design tokens              |
| Animation   | Framer Motion 11                                 |
| State       | Zustand (3 isolated stores)                      |
| UI Primitives | Radix UI (Dialog, Tooltip, ScrollArea)         |
| Icons       | Lucide React                                     |
| Fonts       | Bricolage Grotesque + DM Mono (Google Fonts)     |
| Automation  | n8n (self-hosted or cloud)                       |
| Deployment  | Vercel (Edge-optimised)                          |
| Type Safety | TypeScript strict mode                           |

---

## Project Structure

```
src/
├── app/
│   ├── layout.tsx                  # Root layout — fonts, metadata
│   ├── globals.css                 # Design tokens, grain, orbs
│   ├── page.tsx                    # Studio (main page)
│   ├── analytics/page.tsx          # Analytics dashboard
│   ├── videos/page.tsx             # Video library + table
│   ├── schedules/page.tsx          # Weekly calendar scheduler
│   ├── flows/page.tsx              # n8n flow management
│   └── api/
│       ├── generate/route.ts       # POST dispatch → n8n
│       ├── status/[jobId]/route.ts # GET job status polling
│       └── n8n-callback/route.ts   # POST n8n completion webhook
│
├── components/
│   ├── layout/
│   │   ├── AppShell.tsx            # Shell wrapper (sidebar + topbar)
│   │   ├── Sidebar.tsx             # Collapsible glassmorphic nav
│   │   ├── Topbar.tsx              # Tab nav + credits + avatar
│   │   └── CommandPalette.tsx      # ⌘K global command palette
│   │
│   ├── studio/
│   │   ├── HeroSection.tsx         # Mouse-parallax hero + GeneratorFlow
│   │   ├── GeneratorFlow.tsx       # Input → Processing → Result flow
│   │   ├── OptionsPanel.tsx        # Animated toggle options
│   │   ├── ScriptPreviewModal.tsx  # AI script editor before rendering
│   │   └── JobHistory.tsx          # Slide-in history drawer
│   │
│   ├── video/
│   │   ├── VideoCard.tsx           # Hover-to-play card with sound bars
│   │   ├── VideoGrid.tsx           # Skeleton + filtered grid
│   │   ├── VideoModal.tsx          # Full-screen preview + actions
│   │   └── TemplateRail.tsx        # Horizontal snap-scroll rail
│   │
│   └── ui/
│       ├── Button.tsx              # CVA variants: gold/ghost/glass/danger
│       ├── Badge.tsx               # 6 semantic badge variants
│       ├── GoldBorderCard.tsx      # Pseudo-element gradient border card
│       ├── Modal.tsx               # Radix Dialog + Framer spring
│       ├── Tooltip.tsx             # Radix Tooltip gold-styled
│       └── SkeletonCard.tsx        # Shimmer skeleton components
│
├── hooks/
│   ├── useMouseParallax.ts         # rAF lerp loop → normalised x/y
│   ├── useHoverVideo.ts            # play/pause with cleanup timeout
│   ├── useVideoModal.ts            # open/close modal state
│   ├── useDebounce.ts              # debounce value hook
│   └── useKeyboardShortcut.ts      # cross-platform ⌘/Ctrl handler
│
├── store/
│   └── index.ts                    # Zustand: Generator + Sidebar + UI
│
├── lib/
│   ├── utils.ts                    # cn(), formatNumber(), platformLabel()
│   ├── data.ts                     # Seed videos + templates (Pexels)
│   ├── constants.ts                # Magic strings, keyboard shortcuts
│   └── n8n.ts                      # Server-side n8n webhook client
│
└── types/
    └── index.ts                    # VideoMeta, GenerationJob, etc.
```

---

## Getting Started

### 1. Clone and install

```bash
git clone https://github.com/yourorg/vibeads
cd vibeads
npm install
```

### 2. Configure environment

```bash
cp .env.example .env.local
```

Fill in `.env.local`:

```env
NEXT_PUBLIC_APP_URL=http://localhost:3000
N8N_WEBHOOK_URL=https://your-n8n.cloud/webhook/vibeads/dispatch
N8N_WEBHOOK_SECRET=your_shared_secret
RENDER_API_URL=https://your-render-engine.io
RENDER_API_KEY=your_render_key
VIBEADS_API_KEY=your_internal_key
```

### 3. Run dev server

```bash
npm run dev
# → http://localhost:3000
```

### 4. Type check

```bash
npm run type-check
```

---

## n8n Integration

### Import the workflow

1. Open your n8n dashboard
2. Go to **Workflows → Import**
3. Upload `vibeads-n8n-workflow.json`
4. Set credentials:
   - **Anthropic API Key** — for Claude script generation
   - **Render Engine** — your Remotion Lambda or custom endpoint
   - **Vibeads API Key** — for status callbacks
5. Activate the workflow

### Webhook endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/generate` | Dispatch a new video job |
| `GET`  | `/api/status/:jobId` | Poll job status |
| `POST` | `/api/n8n-callback` | Receive completion callbacks from n8n |

### Test dispatch

```bash
curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://nike.com/air-max-2025",
    "platform": "tiktok",
    "options": {
      "autoCaption": true,
      "brandOverlay": true,
      "n8nDispatch": true
    }
  }'
```

Response:
```json
{
  "jobId": "vb-1720000000000-abc12",
  "status": "queued",
  "estimatedSeconds": 5
}
```

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `⌘K` / `Ctrl+K` | Open command palette |
| `⌘B` / `Ctrl+B` | Toggle sidebar |
| `↑ ↓` in palette | Navigate commands |
| `↵` in palette | Execute command |
| `Esc` | Close any modal / palette |

---

## Deployment

### Vercel (recommended)

```bash
npx vercel --prod
```

Set these environment variables in the Vercel dashboard:
- `N8N_WEBHOOK_URL` → n8n cloud webhook URL
- `N8N_WEBHOOK_SECRET` → shared HMAC secret
- `VIBEADS_API_KEY` → internal API key

### Docker (self-hosted)

```dockerfile
FROM node:20-alpine AS builder
WORKDIR /app
COPY . .
RUN npm ci && npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
COPY --from=builder /app/public ./public
EXPOSE 3000
CMD ["node", "server.js"]
```

```bash
docker build -t vibeads .
docker run -p 3000:3000 --env-file .env.local vibeads
```

---

## Architecture Decisions

**Why Zustand over Context/Redux?**
Three separate stores (Generator, Sidebar, UI) means components only re-render when their slice of state changes. Redux would be overkill; Context would cause full-tree re-renders on every generator update.

**Why Edge Runtime for API routes?**
All API routes run on Vercel's edge network, giving sub-50ms cold starts globally. n8n webhook forwarding is fire-and-forget so the edge timeout isn't a concern.

**Why `useMouseParallax` uses `requestAnimationFrame` + lerp?**
`mousemove` fires at up to 1000Hz. Lerping in `rAF` throttles updates to 60fps and adds spring-like trailing that makes the orb movement feel physical rather than mechanical.

**Why `useHoverVideo` has a 300ms cleanup delay?**
The poster image fade-out CSS transition is 300ms. Resetting `currentTime` before the transition completes causes a visible flash back to frame 0. The timeout ensures the animation finishes before the reset.

**Why pseudo-element gradient borders?**
CSS `border-image` doesn't respect `border-radius`. The `padding` + `mask-composite: exclude` pseudo-element technique achieves true rounded gradient borders at zero JS cost.

---

## License

MIT — see `LICENSE` for details.
